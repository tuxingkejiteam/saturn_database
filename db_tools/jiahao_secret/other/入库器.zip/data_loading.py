import argparse
from rename import load_data
import pymysql
from update_objects import update_objects
from PIL import Image


def main(args):
    load_data(args.img_org_dir,args.img_output_dir,args.json_output_dir) #入库脚本目录下的data目录中的数据（data目录中可包含xml，json等标注文件）
    #update_objects(args.img_output_dir,args.json_output_dir)              #已入库数据标注后将xml,json内容合并在图片关联json中
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--img_org_dir', type=str, default='data')            #导入数据原始目录
    parser.add_argument('--img_output_dir', type=str, default='output')       #导出重命名图片所在目录
    parser.add_argument('--json_output_dir', type=str, default='output_json') #导出重命名图片对应json所在目录
    opt = parser.parse_args()
    assert opt.img_output_dir != opt.img_org_dir, "请检查输出目录是否正确！"
    main(opt)